package swingformulario;

/**
 *
 * @author Fedra Macario
 */
public class Main {
    public static void main(String[] args) {
        FormularioVista vista = new FormularioVista();
        Contacto modelo = new Contacto();
        FormularioControlador controlador = new FormularioControlador(vista, modelo);
        vista.setVisible(true);
    } 
}
