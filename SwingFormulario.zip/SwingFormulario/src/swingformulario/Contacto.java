
package swingformulario;

/**
 *
 * @author Fedra Macario
 */
public class Contacto {
    private String nombre, apellido, dni, pasaporte, telefono, codigoPostal, domicilio;

    // --- GETTERS (Para obtener los datos) ---
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getDni() { return dni; }
    public String getPasaporte() { return pasaporte; }
    public String getTelefono() { return telefono; }
    public String getCodigoPostal() { return codigoPostal; }
    public String getDomicilio() { return domicilio; }

    // --- SETTERS (Para asignar los datos desde el Controlador) ---
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public void setDni(String dni) { this.dni = dni; }
    public void setPasaporte(String pasaporte) { this.pasaporte = pasaporte; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void setCodigoPostal(String codigoPostal) { this.codigoPostal = codigoPostal; }
    public void setDomicilio(String domicilio) { this.domicilio = domicilio; }

    public void validar() throws Exception {
        // 1.Verificar si TODO está vacío
        if (nombre.trim().isEmpty() && apellido.trim().isEmpty() && 
            dni.trim().isEmpty() && pasaporte.trim().isEmpty() && 
            telefono.trim().isEmpty() && codigoPostal.trim().isEmpty() && 
            domicilio.trim().isEmpty()) {

            throw new Exception("El formulario está vacío. Por favor, complete los campos.");
        }
          
        // Validaciones de longitud 
        if (nombre.length() > 20) throw new Exception("Nombre excede 20 caracteres.");
        if (apellido.length() > 20) throw new Exception("Apellido excede 20 caracteres.");
        if (domicilio.length() > 50) throw new Exception("Domicilio excede 50 caracteres.");

        // Dni y Pasaporte: solo uno de ellos puede llevar valor 
        boolean tieneDni = !dni.isEmpty();
        boolean tienePas = !pasaporte.isEmpty();
        if (tieneDni && tienePas) throw new Exception("No puede cargar DNI y Pasaporte simultáneamente.");
        if (!tieneDni && !tienePas) throw new Exception("Debe completar DNI o Pasaporte.");

        // Validación DNI (8 dígitos entre 10M y 60M) 
        if (tieneDni) {
            if (!dni.matches("[0-9]{8}")) throw new Exception("DNI debe ser de 8 dígitos.");
            int d = Integer.parseInt(dni);
            if (d < 10000000 || d > 60000000) throw new Exception("DNI fuera de rango.");
        }

        // Validación Pasaporte (1 letra A-Z y 8 numéricos) 
        if (tienePas) {
            if (!pasaporte.matches("[A-Z][0-9]{8}")) throw new Exception("Formato Pasaporte: 1 letra y 8 números.");
            int numP = Integer.parseInt(pasaporte.substring(1));
            if (numP < 10000000 || numP > 60000000) throw new Exception("Número de pasaporte fuera de rango.");
        }
        
        // Teléfono (> 6 dígitos y símbolos) 
        if (!telefono.matches("[0-9+()\\- ]{7,}")) throw new Exception("Formato de teléfono inválido.");

        // Código Postal (4 dígitos) 
        if (!codigoPostal.matches("[0-9]{4}")) throw new Exception("Código Postal debe tener 4 dígitos.");

    }  
}
