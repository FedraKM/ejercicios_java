package swingformulario;

import javax.swing.JOptionPane;

/**
 *
 * @author Fedra Macario
 */
public class FormularioControlador {
    private FormularioVista vista;
    private Contacto modelo;

    public FormularioControlador(FormularioVista vista, Contacto modelo) {
        this.vista = vista;
        this.modelo = modelo;

        this.vista.btnValidar.addActionListener(e -> ejecutarValidacion());
        this.vista.btnLimpiar.addActionListener(e -> limpiarCampos());
        this.vista.btnCerrar.addActionListener(e -> System.exit(0));
    }

    private void ejecutarValidacion() {
        // Pasar datos de Vista a Modelo
        modelo.setNombre(vista.txtNombre.getText());
        modelo.setApellido(vista.txtApellido.getText());
        modelo.setDni(vista.txtDni.getText());
        modelo.setPasaporte(vista.txtPasaporte.getText());
        modelo.setTelefono(vista.txtTelefono.getText());
        modelo.setCodigoPostal(vista.txtCodigoPostal.getText());
        modelo.setDomicilio(vista.txtDomicilio.getText());

        try {
            modelo.validar(); // Lógica en el modelo
            JOptionPane.showMessageDialog(vista, "Datos válidos.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        vista.txtNombre.setText("");
        vista.txtApellido.setText("");
        vista.txtDni.setText("");
        vista.txtPasaporte.setText("");
        vista.txtTelefono.setText("");
        vista.txtCodigoPostal.setText("");
        vista.txtDomicilio.setText("");
    }
}
